import Foundation

struct Articulo {
    var nombre: String
    var cantidad: Int
}

var inventario: [Articulo] = []

func registrarArticulo() {
    print("Ingrese el nombre del artículo:")
    if let nombre = readLine() {
        print("Ingrese la cantidad:")
        if let cantidadStr = readLine(), let cantidad = Int(cantidadStr) {
            let nuevoArticulo = Articulo(nombre: nombre, cantidad: cantidad)
            inventario.append(nuevoArticulo)
            print("Artículo registrado correctamente.\n")
        } else {
            print("Cantidad inválida.\n")
        }
    }
}

func verListaArticulos() {
    if inventario.isEmpty {
        print("No hay artículos registrados.\n")
    } else {
        print("Lista de Productos:")
        for (index, articulo) in inventario.enumerated() {
            print("Articulo \(index + 1) \(articulo.nombre) \nCantidad \(index + 1) \(articulo.cantidad)")
        }
        print("")
    }
}

func consultarExistencias() {
    let enExistencia = inventario.filter { $0.cantidad > 0 }
    if enExistencia.isEmpty {
        print("No hay artículos en existencia.\n")
    } else {
        print("Artículos en existencia:")
        for (index, articulo) in enExistencia.enumerated() {
            print("Articulo \(index + 1): \(articulo.nombre) \nCantidad \(index + 1): \(articulo.cantidad)")
        }
        print("")
    }
}

func mostrarMenu() {
    var continuar = true
    while continuar {
        print("------ Menú de Inventario ------")
        print("1. Registrar un artículo")
        print("2. Ver la lista de artículos")
        print("3. Consultar artículos en existencia")
        print("4. Salir")
        print("Seleccione una opción:")
        
        if let opcion = readLine() {
            switch opcion {
            case "1":
                registrarArticulo()
            case "2":
                verListaArticulos()
            case "3":
                consultarExistencias()
            case "4":
                continuar = false
                print("Saliendo del programa...")
            default:
                print("Opción inválida. Intente nuevamente.\n")
            }
        }
    }
}

mostrarMenu()