import Foundation

func mostrarMenu() {
    print("""
    Menú de Cálculo de Áreas
    1. Área del Cuadrado
    2. Área del Rectángulo
    3. Área del Triángulo
    4. Área del Círculo
    5. Salir
    Elige una opción (1-5):
    """)
}

func leerNumero(mensaje: String) -> Double {
    print(mensaje, terminator: ": ")
    if let entrada = readLine(), let numero = Double(entrada) {
        return numero
    } else {
        print("Entrada inválida. Inténtalo de nuevo.")
        return leerNumero(mensaje: mensaje)
    }
}

func areaCuadrado() {
    let lado = leerNumero(mensaje: "Ingresa el lado del cuadrado")
    let area = lado * lado
    print("Área del cuadrado: \(area)\n")
}

func areaRectangulo() {
    let base = leerNumero(mensaje: "Ingresa la base del rectángulo")
    let altura = leerNumero(mensaje: "Ingresa la altura del rectángulo")
    let area = base * altura
    print("Área del rectángulo: \(area)\n")
}

func areaTriangulo() {
    let base = leerNumero(mensaje: "Ingresa la base del triángulo")
    let altura = leerNumero(mensaje: "Ingresa la altura del triángulo")
    let area = (base * altura) / 2
    print("Área del triángulo: \(area)\n")
}

func areaCirculo() {
    let radio = leerNumero(mensaje: "Ingresa el radio del círculo")
    let area = Double.pi * radio * radio
    print("Área del círculo: \(area)\n")
}

func iniciarPrograma() {
    var continuar = true
    
    while continuar {
        mostrarMenu()
        if let opcion = readLine() {
            switch opcion {
            case "1":
                areaCuadrado()
            case "2":
                areaRectangulo()
            case "3":
                areaTriangulo()
            case "4":
                areaCirculo()
            case "5":
                print("¡Hasta luego!")
                continuar = false
            default:
                print("Opción no válida. Inténtalo de nuevo.\n")
            }
        }
    }
}

iniciarPrograma()
